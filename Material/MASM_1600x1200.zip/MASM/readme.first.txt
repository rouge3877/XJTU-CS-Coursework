Double click StartAsmEnv.bat to run the ASM programming environment.

The default resolution set by this software is 1600x1200.
